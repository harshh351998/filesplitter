# filesplitter
A Python library to efficiently split large text files into smaller chunks.
